<?php
class Smart_Soulpay_Block_Info_Soulpay extends Mage_Payment_Block_Info
{
  protected function _prepareSpecificInformation($transport = null)
  {
    if (null !== $this->_paymentSpecificInformation) 
    {
      return $this->_paymentSpecificInformation;
    }
     
    $data = array();

    if($this->getInfo()->getFieldCardNumber()) {
      $data[Mage::helper('payment')->__('Card Number')] = $this->getInfo()->getFieldCardNumber();
    }
    
    if($this->getInfo()->getFieldCardExpMonth()) {
      $data[Mage::helper('payment')->__('Card Exp Month')] = $this->getInfo()->getFieldCardExpMonth();
    }

    if($this->getInfo()->getFieldCardExpYear()) {
      $data[Mage::helper('payment')->__('Card Exp Year')] = $this->getInfo()->getFieldCardExpYear();
    }
    
    if($this->getInfo()->getFieldCardCvv()) {
      $data[Mage::helper('payment')->__('Card CVV')] = $this->getInfo()->getFieldCardCvv();
    }
    
    if($this->getInfo()->getFieldCardName()) {
      $data[Mage::helper('payment')->__('Card Name')] = $this->getInfo()->getFieldCardName();
    }
    
    if($this->getInfo()->getFieldCardDocument()) {
      $data[Mage::helper('payment')->__('Card Document')] = $this->getInfo()->getFieldCardDocument();
    }
    
    if($this->getInfo()->getFieldCardInstallments()) {
      $data[Mage::helper('payment')->__('Card Installments')] = $this->getInfo()->getFieldCardInstallments();
    }
    
    $transport = parent::_prepareSpecificInformation($transport);
     
    return $transport->setData(array_merge($data, $transport->getData()));
  }
}