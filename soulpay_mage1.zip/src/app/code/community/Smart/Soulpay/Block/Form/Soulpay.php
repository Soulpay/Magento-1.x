<?php
class Smart_Soulpay_Block_Form_Soulpay extends Mage_Payment_Block_Form
{
  protected function _construct()
  {
    parent::_construct();
    $this->setTemplate('soulpay/form/soulpay.phtml');
  }
}