<?php
class Smart_Soulpay_Block_Form_Soulpaybs extends Mage_Payment_Block_Form
{
  protected function _construct()
  {
    parent::_construct();
    $this->setTemplate('soulpay/form/soulpaybs.phtml');
  }
}