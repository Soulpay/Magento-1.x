<?php
$installer = $this;
$installer->startSetup();
$installer->run("
ALTER TABLE `{$installer->getTable('sales/quote_payment')}` 
    ADD `field_card_exp_month` VARCHAR( 255 ) NOT NULL,    
    ADD `field_card_exp_year` VARCHAR( 255 ) NOT NULL,    
    DROP `field_card_exp_date`;
  
ALTER TABLE `{$installer->getTable('sales/order_payment')}` 
    ADD `field_card_exp_month` VARCHAR( 255 ) NOT NULL,    
    ADD `field_card_exp_year` VARCHAR( 255 ) NOT NULL,    
    DROP `field_card_exp_date`;
");
$installer->endSetup();