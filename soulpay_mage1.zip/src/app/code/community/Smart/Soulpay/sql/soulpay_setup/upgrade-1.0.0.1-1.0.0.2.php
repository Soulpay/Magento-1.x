<?php
$installer = $this;
$installer->startSetup();
$installer->run("
ALTER TABLE `{$installer->getTable('sales/quote_payment')}` 
    ADD `field_bs_name` VARCHAR( 255 ) NOT NULL,
    ADD `field_bs_document` VARCHAR( 255 ) NOT NULL;
  
ALTER TABLE `{$installer->getTable('sales/order_payment')}` 
    ADD `field_bs_name` VARCHAR( 255 ) NOT NULL,
    ADD `field_bs_document` VARCHAR( 255 ) NOT NULL;
");
$installer->endSetup();