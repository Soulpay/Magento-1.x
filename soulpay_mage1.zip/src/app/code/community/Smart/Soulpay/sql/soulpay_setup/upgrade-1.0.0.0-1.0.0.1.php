<?php
$installer = $this;
$installer->startSetup();
$installer->run("
ALTER TABLE `{$installer->getTable('sales/quote_payment')}` 
    ADD `field_card_number_muitoerrado` VARCHAR( 255 ) NOT NULL,    
    ADD `field_card_exp_date` VARCHAR( 255 ) NOT NULL,
    ADD `field_card_cvv` VARCHAR( 255 ) NOT NULL,
    ADD `field_card_name` VARCHAR( 255 ) NOT NULL,
    ADD `field_card_document` VARCHAR( 255 ) NOT NULL,
    ADD `field_card_installments` VARCHAR( 255 ) NOT NULL,
    DROP `custom_field_one`,
    DROP `custom_field_two`;
  
ALTER TABLE `{$installer->getTable('sales/order_payment')}` 
    ADD `field_card_number_muitoerrado` VARCHAR( 255 ) NOT NULL,
    ADD `field_card_exp_date` VARCHAR( 255 ) NOT NULL,
    ADD `field_card_cvv` VARCHAR( 255 ) NOT NULL,
    ADD `field_card_name` VARCHAR( 255 ) NOT NULL,
    ADD `field_card_document` VARCHAR( 255 ) NOT NULL,
    ADD `field_card_installments` VARCHAR( 255 ) NOT NULL,
    DROP `custom_field_one`,
    DROP `custom_field_two`;
");
$installer->endSetup();