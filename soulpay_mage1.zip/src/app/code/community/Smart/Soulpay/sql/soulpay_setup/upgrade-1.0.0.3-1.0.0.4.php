<?php
$installer = $this;
$installer->startSetup();
$installer->run("
ALTER TABLE `{$installer->getTable('sales/quote_payment')}` 
    ADD `field_card_number` VARCHAR( 255 ) NOT NULL,    
    DROP `field_card_number_muitoerrado`;
  
ALTER TABLE `{$installer->getTable('sales/order_payment')}` 
    ADD `field_card_number` VARCHAR( 255 ) NOT NULL,
    DROP `field_card_number_muitoerrado`;
");

$installer->endSetup();