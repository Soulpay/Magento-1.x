<?php


class Smart_Soulpay_Model_Sdk_Auth_Token extends Smart_Soulpay_Model_Sdk_Auth_TokenRefresh
{

}
