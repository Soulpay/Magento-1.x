<?php

class Smart_Soulpay_Model_Sdk_Address_Billing extends Smart_Soulpay_Model_Sdk_Address_Address
{}
