<?php
class Smart_Soulpay_Model_Soulpay extends Mage_Payment_Model_Method_Abstract {
  protected $_code  = 'soulpay';
  protected $_formBlockType = 'soulpay/form_soulpay';
  protected $_infoBlockType = 'soulpay/info_soulpay';
 
  protected $_canCapture = true;

  public function assignData($data)
  {
    $info = $this->getInfoInstance();

    $ccNumber = $data->getFieldCardNumber();
    $ccNumber = preg_replace('/\D/', '', $ccNumber);
    $info->setFieldCardNumber($ccNumber);

    $info->setFieldCardExpMonth($data->getFieldCardExpMonth());

    $info->setFieldCardExpYear($data->getFieldCardExpYear());

    $info->setFieldCardCvv($data->getFieldCardCvv());

    $info->setFieldCardName($data->getFieldCardName());

    $document = $data->getFieldCardDocument();
    $document = preg_replace('/\D/', '', $document);
    $info->setFieldCardDocument($document);

    $info->setFieldCardInstallments($data->getFieldCardInstallments());
 
    return $this;
  }

  public function capture(Varien_Object $payment, $amount)
  {
    $soulpay = new Smart_Soulpay_Model_SoulpayUtil($this->getConfigData('email'), $this->getConfigData('password'), $this->getConfigData('env'));

    $order = $payment->getOrder();

    $result = $soulpay->payCreditCard($order);

    $payment->setFieldCardNumber('XXXX-XXXX-XXXX-'.substr($payment->getFieldCardNumber(),-4));
    $payment->setFieldCardCvv('***');

    if($result["httpCode"] >= 400 || $result["response"]['apiResponse'] == 'DENIED' || $result["response"]['apiResponse'] == 'DECLINED') {
      
      if($result["httpCode"] >= 500 ) {         
        Mage::throwException('Erro interno do servidor');
      }
      
      Mage::throwException('Compra recusada - Motivo: '. $result["response"]['errors'][0]['field']);
    }

    if($result["httpCode"] == 200 && $result["response"]['apiResponse'] == 'CAPTURED') {
      try {
        $order->getPayment()->setAdditionalData(json_encode($result['response']));
      } catch (Exception $e) {
        Mage::throwException('Erro interno do servidor');
       } 
    }

    if($result["httpCode"] == 200 && $result["response"]['apiResponse'] == 'REVIEWING') {
      try {            
        $order->getPayment()->setAdditionalData(json_encode($result['response']));  
        $payment->setIsTransactionPending(true);    
      } catch (Exception $e) {
        Mage::throwException('Erro interno do servidor');
      }
    }
    
    $info = json_decode($order->getPayment()->getAdditionalData(), true);
    $payment->setTransactionId($info["orderId"]);

    foreach ($order->getInvoiceCollection() as $invoice) {
      if($info['apiResponse'] == 'REVIEWING') {
        $invoice->setState($invoice::STATE_OPEN);
      }
    }

    return $this;
  }

  public function validate()
  {
    parent::validate();
 
    return $this;
  }

}