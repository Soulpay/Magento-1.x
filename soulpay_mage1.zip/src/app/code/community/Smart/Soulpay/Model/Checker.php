<?php

class Smart_Soulpay_Model_Checker
{
    private $soulpaycc;
    private $soulpaybs;
 
    public function check()
    {
        echo 'Started Soulpay Job' . PHP_EOL;

        $this->initSoulpaycc();
        $this->initSoulpaybs();
        $this->executeBoleto();
        $this->executeCc();

        echo 'Ended Soulpay Job' . PHP_EOL;
        return $this;
    }

    function initSoulpaycc() {
        $email = Mage::getStoreConfig('payment/soulpay/email');
        $password = Mage::getStoreConfig('payment/soulpay/password');
        $env = Mage::getStoreConfig('payment/soulpay/env');
        $this->soulpaycc = new Smart_Soulpay_Model_SoulpayUtil($email, $password, $env);
    }

    function initSoulpaybs() {
        $email = Mage::getStoreConfig('payment/soulpaybs/email');
        $password = Mage::getStoreConfig('payment/soulpaybs/password');
        $env = Mage::getStoreConfig('payment/soulpaybs/env');
        $this->soulpaybs = new Smart_Soulpay_Model_SoulpayUtil($email, $password, $env);
    }

    function executeBoleto() {
        $orders = Mage::getModel('sales/order')->getCollection()
            ->addFieldToFilter('status', 'pending_payment');

        echo count($orders) . ' boletos' . PHP_EOL;

        foreach ($orders as $order) {

            if($order->getPayment()->getMethod() !== 'soulpaybs') {
                $this->cancelOrder($order, "cartao em pending_payment", false);
                continue;
            }

            $bsData = json_decode($order->getPayment()->getAdditionalData(), true);

            if(!$bsData) {
                $this->cancelOrder($order, "Boleto sem data", false);
                continue;
            }

            $now = new DateTime();
            $expDate = DateTime::createFromFormat('Y-m-d', $bsData['bankSlipExpDate']);
            $diferenca = $now->diff($expDate);

            //boleto vencido/expirado
            if(intval($diferenca->format('%r%a')) < -31) {
                $this->cancelOrder($order, 'Boleto Vencido ou Expirado', false);
                continue;
            }
            
            try{
                //dados do boleto do provedor de pagamento
                $check = $this->soulpaybs->getBankSlip($bsData["orderId"]);
            } catch(\Exception $e) {
                continue;
            }

            //boleto revogado
            if($check["response"]["isRevoked"] == 1) {
                $this->cancelOrder($order, 'Boleto Expirado', false);
                continue;
            }
            
            //boleto pago
            if($check["response"]["paid"] == 1) {
                $this->processOrder($order, "Boleto Pago");
                $order->getPayment()->capture(null);
                foreach ($order->getInvoiceCollection() as $invoice) {
                    $invoice->setTransactionId($check["response"]["orderId"]);
                    $invoice->save();
                }
            }
        }
    }
    
    function executeCc() {
        $orders = Mage::getModel('sales/order')->getCollection()
            ->addFieldToFilter('status', 'payment_review');

        echo count($orders) . ' cartoes' . PHP_EOL;
        
        foreach ($orders as $order) {

            //se nao for cartao pula fora
            if($order->getPayment()->getMethod() !== 'soulpay') {
                $this->cancelOrder($order, "boleto em processing-pending/payment_review");
                continue;
            }

            $ccData = json_decode($order->getPayment()->getAdditionalData(), true);

            //sem data de response sem check
            if(!$ccData) {
                $this->cancelOrder($order, "cartao sem data");
                continue;
            }
            
            try{
                //dados do cartao do provedor de pagamento
                $check = $this->soulpaycc->getCreditCard($ccData["orderId"]);
            } catch(\Exception $e) {
                continue;
            }
                        
            //sem invoice = gg
            if(count($order->getInvoiceCollection()) == 0) {
                $this->cancelOrder($order, "Sem invoice");
                continue;
            }
            
            switch (intval($check['response']['status'])) {
                case 1: //APROVED
                    $this->processOrder($order, "Cartao Aceito");
                    foreach ($order->getInvoiceCollection() as $invoice) {
                        if ($invoice->getTransactionId() == $check["response"]["orderId"]) {
                            $invoice->setState($invoice::STATE_PAID);
                            $invoice->save();
                        }
                    }
                    break;
                case 2: //DANIED
                case 7: //CAPTURE FAIL
                case 8: //RECURRENCE FAIL
                    $this->cancelOrder($order, "Cartao Recusado");
                    break;
                case 3: //ANALYSIS
                case 4: //NOT REPORTED
                case 5: //PROCESSING
                case 6: //IN TROUBLESHOOTING
                case 9: //CREATED
                    break;
            }
        }
        
    }

    // $isCartao pq o boleto só gera invoice quando é pago
    function cancelOrder($order, $msg, $isCartao = true) {
        $timestamp = new DateTime();
        $order->getPayment()->setAdditionalInformation("status", $msg);
        $order->getPayment()->setAdditionalInformation("timestamp", $timestamp->getTimestamp());
        $order->getPayment()->save();

        if($order->getState == $order::STATE_PAYMENT_REVIEW) {
            $order->getPayment()->deny();
        } else {
            $order->cancel();
        }

        $data = null;
        if($order->getPayment()->getAdditionalData()) {
            $data = json_decode($order->getPayment()->getAdditionalData(), true);
        }
        
        if($isCartao && !is_null($data)){
            foreach ($order->getInvoiceCollection() as $invoice) {
                if ($invoice->getTransactionId() == $data["orderId"]) {
                    $invoice->setState($invoice::STATE_CANCELED);
                    $invoice->save();
                }
            }
        }

        $order->setState($order::STATE_CANCELED, true, $msg);
        $order->save();
    }

    function processOrder($order, $msg) {
        $timestamp = new DateTime();
        $order->getPayment()->setAdditionalInformation("status", $msg);
        $order->getPayment()->setAdditionalInformation("timestamp", $timestamp->getTimestamp());
        $order->getPayment()->save();

        if($order->getState == $order::STATE_PAYMENT_REVIEW) {
            $order->getPayment()->accept();
        }
        
        $order->setTotalPaid($order->getGrandTotal());
        $order->setState($order::STATE_PROCESSING, true, $msg);
        $order->save();
    }
 
}