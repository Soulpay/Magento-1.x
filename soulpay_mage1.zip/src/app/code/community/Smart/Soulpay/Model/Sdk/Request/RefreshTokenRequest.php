<?php


class Smart_Soulpay_Model_Sdk_Request_RefreshTokenRequest extends Smart_Soulpay_Model_Sdk_Request_TokenRefreshRequest
{

    public function __construct($jwt,$isProduction = true)
    {
        parent::__construct("auth/new-refresh-token", $jwt, $isProduction);
    }

    public function send($data)
    {
        return json_encode(parent::send($data));
    }

}
