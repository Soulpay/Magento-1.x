<?php

class Smart_Soulpay_Model_SoulpayUtil {
    private $token;
    private $email;
    private $password;
    private $environment;

    public function __construct($email, $password, $environment)
    {
        $this->email = $email;
        $this->password = $password;
        $this->environment = boolval($environment);
    }

    public function getToken()
    {
        try {
            $login = new Smart_Soulpay_Model_Sdk_Auth_Login();
            $login->setEmail($this->email);
            $login->setPassword($this->password);

            $loginRequest = new Smart_Soulpay_Model_Sdk_Request_LoginRequest($this->environment);

            $response = $loginRequest->send(json_encode($login));

            $response['response'] = json_decode($response['response'], true);

            $this->token = (object)[
                'type' => $response['response']['type'],
                'token' => $response['response']['token'],
                'refreshToken' => $response['response']['refreshToken'],
                'creatDate' => new \DateTime('+ 15 minutes')
            ];

            return $this->token;
        } catch(\Exception $e) {
            Mage::throwException("Falha no login da Soulpay");
        }
    }

    public function customer($order)
    {
        $customer = new Smart_Soulpay_Model_Sdk_Customer_Customer();

        $address = $order->getBillingAddress();

        $customer->setId($address->getEmail());
        $customer->setName($address->getFirstname()." ".$address->getLastname());
        $customer->setEmail($address->getEmail());
        $customer->setDob("1995-09-16");
        
        $customer->setPhone1($address->getTelephone());
        $customer->setPhone2($address->getTelephone());

        if($order->getPayment()->getFieldCardDocument()) {
            $customer->setTaxId($order->getPayment()->getFieldCardDocument());
        } else {
            if($order->getPayment()->getFieldBsDocument()) {
                $customer->setTaxId($order->getPayment()->getFieldBsDocument());
            } else {
                $customer->setTaxId('76949652070');
                //cpf gerado na net, era pra da panico aqui
            }
        }

        return $customer;
    }

    public function billing($order)
    {
        $billing = new Smart_Soulpay_Model_Sdk_Address_Billing();

        $address = $order->getBillingAddress();

        $street = $address->getStreet();
        if(!isset($street[1])) {
            $street[1] = '';
        }

        $billing->setName($address->getFirstname()." ".$address->getLastname());
        $billing->setAddress($street[0]);
        $billing->setAddress2($street[1]);
        $billing->setDistrict($street[0]);
        $billing->setCity($address->getCity());
        $billing->setState($address->getRegionCode());

        $cep = $address->getPostcode();
        $cep = preg_replace('/\D/', '', $cep);
        $billing->setPostalCode($cep);

        $billing->setCountry($address->getCountryId());
        $billing->setPhone($address->getTelephone());
        $billing->setEmail($address->getEmail());

        return $billing;
    }

    public function creditCard($ccData)
    {
        $creditCard = new Smart_Soulpay_Model_Sdk_Transaction_CreditCard();

        $creditCard->setCardHolderName($ccData->getFieldCardName());
        $creditCard->setNumber($ccData->getFieldCardNumber());
        $creditCard->setExpDate($ccData->getFieldCardExpMonth() . '/' . $ccData->getFieldCardExpYear());
        $creditCard->setCvvNumber($ccData->getFieldCardCvv());

        return $creditCard;
    }

    public function payCreditCard($order)
    {
        $customer = $this->customer($order);

        $billing = $this->billing($order);

        $ccData = $order->getPayment();

        $creditCard = $this->creditCard($ccData);

        $creditInstallment = new Smart_Soulpay_Model_Sdk_Transaction_CreditInstallment();

        $creditInstallment->setNumberOfInstallments($ccData->getFieldCardInstallments());

        $payment = new Smart_Soulpay_Model_Sdk_Transaction_Payment();

        $payment->setChargeTotal(floatval($order->getGrandTotal()));
        $payment->setCurrencyCode('BRL');
        $payment->setCreditInstallment($creditInstallment);

        $creditCardTransaction = new Smart_Soulpay_Model_Sdk_Transaction_CreditCardTransaction();

        $creditCardTransaction->setReferenceNum($order->getIncrementId());
        $creditCardTransaction->setCustomer($customer);
        $creditCardTransaction->setBilling($billing);
        $creditCardTransaction->setCreditCard($creditCard);
        $creditCardTransaction->setPayment($payment);

        // Passar o token JWT aqui.
        $request = new Smart_Soulpay_Model_Sdk_Request_CreditCardRequest($this->getToken()->token, $this->environment);

        try {
            $payment = json_decode($request->send(json_encode($creditCardTransaction)));
            $payment->response = json_decode($payment->response, true);
        } catch(\Exception $e) {
            $msg = $e->getMessage();
            Mage::exception("Nao Gerou Token {$msg} ");
        }

        $payment->response['installments'] = $ccData->getFieldCardInstallments();
        $payment = json_decode(json_encode($payment), true);

        return $payment;
    }

    public function generateBankSlip($order, $bsExtraData) {

        $customer = $this->customer($order);

        $billing = $this->billing($order);

        $bankSlip = new Smart_Soulpay_Model_Sdk_Transaction_BankSlip();
        $bankSlip->setExpirationDate($bsExtraData['expdate']);
        $bankSlip->setInstructions($bsExtraData['instructions']);

        $payment = new Smart_Soulpay_Model_Sdk_Transaction_Payment();
        $payment->setChargeTotal(floatval($order->getGrandTotal()));
        $payment->setCurrencyCode('BRL');

        $bankSlipTransaction = new Smart_Soulpay_Model_Sdk_Transaction_BankSlipTransaction();
        $bankSlipTransaction->setReferenceNum($order->getIncrementId());
        $bankSlipTransaction->setCustomer($customer);
        $bankSlipTransaction->setBilling($billing);
        $bankSlipTransaction->setBankSlip($bankSlip);
        $bankSlipTransaction->setPayment($payment);

        $request = new Smart_Soulpay_Model_Sdk_Request_BankSlipRequest($this->getToken()->token, $this->environment);

        try {
            $payment = json_decode($request->send(json_encode($bankSlipTransaction)));
            $payment->response = json_decode($payment->response, true);
        } catch(\Exception $e) {
            $msg = $e->getMessage();
        }

        $payment = json_decode(json_encode($payment), true);

        return $payment;
    }

    public function getBankSlip($id) {
        try {
            $request = new Smart_Soulpay_Model_Sdk_Request_BankSlipRequest($this->getToken()->token, $this->environment);
            $response = $request->get($id);
            $response["response"] = json_decode($response["response"], true);
        } catch (Exception $e) {
            throw $e;
        }
        return $response;
    }

    public function getCreditCard($id) {
        try {
            $request = new Smart_Soulpay_Model_Sdk_Request_CreditCardRequest($this->getToken()->token, $this->environment);
            $response = $request->get($id);
            $response["response"] = json_decode($response["response"], true);
        } catch (Exception $e) {
            throw $e;
        }
        return $response;
    }
}

?>