<?php

class Smart_Soulpay_Model_Installments
{

    public function toOptionArray()
    {
        for ($i = 1; $i <= 12; $i++) {
            $options[] = array(
               'value' => $i,
               'label' => $i
            );
        }
        return $options;
    }
}
