<?php


abstract class Smart_Soulpay_Model_Sdk_Request_Request
{
    protected $url;

    public function __construct($url, $isProduction)
    {
        if ($isProduction) {
            $this->url = "https://mercury.viainvestgrupo.com.br/api/v1/";
        } else {
            $this->url = "https://dev-api.portalsoulpay.com.br/api/v1/";
        }
        $this->url = $this->url . $url;
    }
}
