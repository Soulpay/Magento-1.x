<?php
class Smart_Soulpay_Model_Soulpaybs extends Mage_Payment_Model_Method_Abstract {
  protected $_code  = 'soulpaybs';
  protected $_formBlockType = 'soulpay/form_soulpaybs';
  protected $_infoBlockType = 'soulpay/info_soulpaybs';
 
  static $DOMINGO = '0';
  static $SABADO = '6';

  public function assignData($data)
  {
    $info = $this->getInfoInstance();
    $document = $data->getFieldBsDocument();
    $document = preg_replace('/\D/', '', $document);
    $info->setFieldBsDocument($document);
  
    return $this;
  }

  public function authorize(Varien_Object $payment, $amount)
  {
    $soulpay = new Smart_Soulpay_Model_SoulpayUtil($this->getConfigData('email'), $this->getConfigData('password'), $this->getConfigData('env'));
    $expdays = $this->getConfigData('expdays');
    $expdate = new DateTime();
    $interval = new DateInterval("P1D");

    for($i = 0; $i < $expdays; $i++) {
      do {
        $expdate->add($interval);
      } while($expdate->format('w') == self::$DOMINGO || $expdate->format('w') == self::$SABADO || $this->isFeriado($expdate));
    }

    $bsExtraData = array (
      "instructions" => $this->getConfigData('instructions'),
      "expdate" => $expdate->format('Y-m-d')
    );

    $order = $payment->getOrder();
    $result = $soulpay->generateBankSlip($order, $bsExtraData);

    if($result["httpCode"] >= 400 || in_array($result["response"]['apiResponseCode'], [ 1024, 1 , 2, 3, 7]) ) {
      if($result["httpCode"] >= 500 ) {           
        Mage::throwException('Erro interno do servidor');
      }

      if ( isset($result["response"]['errors']) ) {
        $msg = isset($result["response"]['errors'][0]['field']) ? $result["response"]['errors'][0]['field'] : '';
        Mage::throwException('Erro ao gerar o boleto '. $msg);
      } else {
        Mage::throwException('Erro ao gerar o boleto - Verifique o documento utilizado e tente novamente.');
      }

    } 

    else if($result["httpCode"] == 200 && $result["response"]['apiResponseCode'] == 0) {
      try {
        $order->getPayment()->setAdditionalData(json_encode($result['response']));
      } catch (Exception $e) {
        Mage::throwException('Erro interno do servidor');
      }
    }

    else {
      Mage::throwException('Erro Inesperada');
    }

    return $this;
  }
 
  public function validate()
  {
    parent::validate();
    return $this;
  }
 
  //https://gist.github.com/guiliredu/fc5ae6c9f1033384169c3b8c75f4cd61
  function isFeriado(DateTime $data = null)
  {
      if(empty($data))
      {
          $data = new DateTime();
      }

      $ano = $data->format('Y');

      $pascoa = easter_date($ano); // Limite de 1970 ou após 2037 da easter_date PHP consulta http://www.php.net/manual/pt_BR/function.easter-date.php
      $dia_pascoa = date('j', $pascoa);
      $mes_pascoa = date('n', $pascoa);
      $ano_pascoa = date('Y', $pascoa);

      $feriados = array(
          // Datas Fixas dos feriados Nacionais Brasileiras
          mktime(0, 0, 0, 1, 1, $ano), // Confraternização Universal - Lei nº 662, de 06/04/49
          mktime(0, 0, 0, 4, 21, $ano), // Tiradentes - Lei nº 662, de 06/04/49
          mktime(0, 0, 0, 5, 1, $ano), // Dia do Trabalhador - Lei nº 662, de 06/04/49
          mktime(0, 0, 0, 9, 7, $ano), // Dia da Independência - Lei nº 662, de 06/04/49
          mktime(0, 0, 0, 10, 12, $ano), // N. S. Aparecida - Lei nº 6802, de 30/06/80
          mktime(0, 0, 0, 11, 2, $ano), // Todos os santos - Lei nº 662, de 06/04/49
          mktime(0, 0, 0, 11, 15, $ano), // Proclamação da republica - Lei nº 662, de 06/04/49
          mktime(0, 0, 0, 12, 25, $ano), // Natal - Lei nº 662, de 06/04/49

          // Essas Datas dependem diretamente da data de Pascoa
          mktime(0, 0, 0, $mes_pascoa, $dia_pascoa - 48, $ano_pascoa), //2ºferia Carnaval
          mktime(0, 0, 0, $mes_pascoa, $dia_pascoa - 47, $ano_pascoa), //3ºferia Carnaval
          mktime(0, 0, 0, $mes_pascoa, $dia_pascoa - 2, $ano_pascoa), //6ºfeira Santa
          mktime(0, 0, 0, $mes_pascoa, $dia_pascoa, $ano_pascoa), //Pascoa
          mktime(0, 0, 0, $mes_pascoa, $dia_pascoa + 60, $ano_pascoa), //Corpus Cirist
      );

      sort($feriados);

      $check = mktime(0, 0, 0, $data->format('m'), $data->format('d'), $ano);

      return in_array($check, $feriados);
  }
}