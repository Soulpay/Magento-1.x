<?php

class Smart_Soulpay_Model_Sdk_Auth_RefreshToken extends Smart_Soulpay_Model_Sdk_Auth_TokenRefresh
{

}
