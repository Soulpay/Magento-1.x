<?php

class Smart_Soulpay_Model_Sdk_Address_Shipping extends Smart_Soulpay_Model_Sdk_Address_Address
{}
