<?php
class Smart_Soulpay_Helper_Data extends Mage_Core_Helper_Abstract
{
  function getPaymentGatewayUrl() 
  {
    return Mage::getUrl('soulpay/payment/gateway', array('_secure' => false));
  }
}